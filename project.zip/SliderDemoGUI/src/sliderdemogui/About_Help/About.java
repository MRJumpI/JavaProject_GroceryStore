
package sliderdemogui.About_Help;

import EndUsers.AdminPortal;
import EndUsers.Customer;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import project.DashBoard;

public class About extends JFrame {
    private static String nextScreen;
    private static JLabel imageLabel;
    private static ImageIcon[] images;
    private static int currentImage = 0;
    private static int numImages;
    private static int delay = 2000; // 3 seconds
    public static final int WIDTH=1090;
    public static final int HEIGHT=630;
    public static TestButton btnBack=new TestButton("GO BACK");
    public static String name;
    
    public About(String[] imageFiles,String nextScreen,String name) {
        this.nextScreen=nextScreen;
        this.name=name;
        Font ft=new Font(Font.SANS_SERIF, Font.BOLD, 14);
                 
        JPanel bgSet=new JPanel(new GridLayout(1,2));
        bgSet.setBounds(0,0,WIDTH,HEIGHT);
        bgSet.setBackground(new Color(53,53,53));

        JPanel leftSide= new JPanel(null);
        leftSide.setLayout(null);
        leftSide.setBackground(new Color(53,53,53));
        bgSet.add(leftSide);

        //Slider
        btnBack.setHoverBackgroundColor(new Color(53,53,53));
        btnBack.setPressedBackgroundColor(new Color(0,204,0));
        btnBack.setForeground(Color.WHITE);
        btnBack.setBackground(new Color(0,0,0));
        btnBack.setBounds(10,10,110,50);
        btnBack.setFocusable(false);
        btnBack.setBorder(null);
        btnBack.setVisible(true);
        btnBack.setFont(ft);
        btnBack.setIcon(new ImageIcon(getClass().getResource("./back-arrow.png")));
        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               
                if(nextScreen.equalsIgnoreCase("dashboard")){
                    About.super.dispose();        
                    new DashBoard().setVisible(true);
                 return;
                }
                else if(nextScreen.equalsIgnoreCase("customer")){
                    About.super.dispose();             
                    new Customer(name).setVisible(true);
                    return;
                }
                else if(nextScreen.equalsIgnoreCase("admin")){
                    About.super.dispose();        
                    new AdminPortal(name).setVisible(true);
                 return;
                }
                
                
            }
        });
        
        //Heading 
        JLabel heading = new JLabel();
        heading.setText("<html> <h1> ABOUT - <span color=\"rgb(0,204,0)\"> GROCERY STORE </span></h1> </html>");
        heading.setForeground(Color.WHITE);
        heading.setBounds(100,80,420,90);    
        JSeparator separator = new JSeparator();
        separator.setBounds(80,150,350,5);
        separator.setForeground(new Color(10,10,10));
        separator.setBackground(new Color(10,10,10));

        JLabel paragraph=new JLabel();
        paragraph.setBounds(100,150,300,150);
        paragraph.setForeground(Color.WHITE);
        paragraph.setText("<html> <p>Hello and Welocome to -<span color=\"rgb(0,204,0)\"> GROCERY STORE </span>- here we are to provide you services of shopping. Feeling lazy and you also have to do your  <span color=\"rgb(0,204,0)\"> grocery </span>; You have a hard day feeling tired & you want to do <span color=\"rgb(0,204,0)\"> grocery </span>.. So just open the app <span color=\"rgb(0,204,0)\">create account</span> and do all the <span color=\"rgb(0,204,0)\">grocery.</span>. <p></html>");
        paragraph.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

        JSeparator helpseparator = new JSeparator();
        helpseparator.setBounds(50,320,450,5);
        helpseparator.setForeground(new Color(90,90,90));
        helpseparator.setBackground(new Color(90,90,90));

        JLabel helpHeading = new JLabel();
        helpHeading.setText("<html> <h1> HELP / SUPPORT - <span color=\"rgb(0,204,0)\"> GROCERY STORE </span></h1> </html>");
        helpHeading.setIcon(new ImageIcon(getClass().getResource("./001-handshake.png")));
        helpHeading.setIconTextGap(20);
        helpHeading.setForeground(Color.WHITE);
        helpHeading.setBounds(100,340,420,90);    
        JLabel helpparagraph=new JLabel();
        helpparagraph.setBounds(100,360,300,150);
        helpparagraph.setForeground(Color.WHITE);
        helpparagraph.setText("<html> <p>You can find help by using following : <p></html>");
        helpparagraph.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        leftSide.add(helpparagraph);

        JLabel helpparagraphP1=new JLabel();
        helpparagraphP1.setBounds(100,420,320,150);
        helpparagraphP1.setForeground(Color.WHITE);
        helpparagraphP1.setText("<html> <ul color=\" rgb(0,204,0) \">  </html>" );
        helpparagraphP1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        helpparagraphP1.setIcon(new ImageIcon(getClass().getResource("./002-email.png")));
        helpparagraphP1.setIconTextGap(20);
        leftSide.add(helpparagraphP1);
        
        JLabel helpparagraphP2=new JLabel();
        helpparagraphP2.setBounds(100,470,350,150);
        helpparagraphP2.setForeground(Color.WHITE);
        helpparagraphP2.setText("<html> <ul> <li>  </li> </ul></html>");
        helpparagraphP2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        helpparagraphP2.setIcon(new ImageIcon(getClass().getResource("./003-smartphone-call.png")));
        helpparagraphP2.setIconTextGap(20);
        leftSide.add(helpparagraphP2);


        leftSide.add(helpHeading);
        leftSide.add(helpseparator);
        leftSide.add(paragraph);
        leftSide.add(separator);
        leftSide.add(heading);
        leftSide.add(btnBack);
        numImages = imageFiles.length;
        images = new ImageIcon[numImages];



        for (int i = 0; i < numImages; i++) {
            images[i] = new ImageIcon(getClass().getResource(imageFiles[i]));
        }

        imageLabel = new JLabel(images[0]);
        bgSet.add(imageLabel);
      

        Timer timer = new Timer(delay, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentImage = (currentImage + 1) % numImages;
                imageLabel.setIcon(images[currentImage]);
            }
        });
        timer.start();
        //slider -end
        add(bgSet);
        setTitle("About Us");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
    }

}