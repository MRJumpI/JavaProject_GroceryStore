/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package EndUsers;

import java.awt.Color;
import java.awt.Font;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import sliderdemogui.About_Help.About;
import project.DashBoard;
/**
 *
 * @author musma
 */
public class Customer extends javax.swing.JFrame {
 public static String name;
    /**
    /**
     * Creates new form Customer
     */
    public static DefaultTableModel itemCartModel = new DefaultTableModel();
   
    public static String filename = ""; 
    
    public Customer(String name) {
        
        initComponents();
        this.name=name;
        
        filename = this.name+"ItemRecord";
        userNameSet.setText(this.name);
        panelShoppingCart.setVisible(false);
        importPanel.setVisible(false);
        itemRecord.getTableHeader().setBackground(new Color(0, 204, 0));
        itemRecord.getTableHeader().setForeground(new Color(255, 255, 255));
        itemRecord.getTableHeader().setFont(new Font("Segoe UI Historic", Font.BOLD, 24));
      
        itemRecord.getTableHeader().setBorder(null);
        itemCart.getTableHeader().setBackground(new Color(0, 204, 0));
        itemCart.getTableHeader().setForeground(new Color(255, 255, 255));
        itemCart.getTableHeader().setFont(new Font("Segoe UI Historic", Font.BOLD, 24));
        panelThank.setVisible(false);
        itemCart.getTableHeader().setBorder(null);
        readFile(itemRecord,filename);
       
    }
    
    public static void readFile(JTable table,String fname) {
     long id=1;
     ArrayList<String> name=new ArrayList<>();
     ArrayList<String> quantity=new ArrayList<>();
     ArrayList<String> price=new ArrayList<>();
     System.out.print(fname+"-ReadFile");
     
     try (FileInputStream fis = new FileInputStream(fname+".data");
             DataInputStream dis = new DataInputStream(fis)) {
           while(true){ 
            String storedName = dis.readUTF();
            String storedQantity = dis.readUTF();
            String storedPrice = dis.readUTF();
            name.add(storedName);
            quantity.add(storedQantity);
            price.add(storedPrice);
             }
           

        }catch(EOFException e){
         JOptionPane.showMessageDialog(null,"File Read Successfuly!"+e.toString());
        
        }catch(Exception e){
         JOptionPane.showMessageDialog(null,"Make sure there is user for which you wanted to import file...!"+e.toString());
        }
      
      DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

//        //total
//       System.out.println(name.size());

      for(int i = 0;i<name.size();i++) {
                int row = model.getRowCount();
                System.out.println(row);
                model.addRow(new Object[]{});
                model.setValueAt(id, row, 0);
                model.setValueAt(name.get(i), row, 1);
                model.setValueAt(quantity.get(i), row, 2);
                model.setValueAt(Double.parseDouble(price.get(i)), row, 3);
                id=id+1;
             }
        
    }
 
    private static void writeFile(JTable table){
     
                   //filing here
        //create ArrayLists for each column
ArrayList<String> column2 = new ArrayList<>();
ArrayList<String> column3 = new ArrayList<>();
ArrayList<String> column4 = new ArrayList<>();
//get the number of rows in the table
int rowCount =table.getRowCount();
System.out.println(rowCount+"RowCount");
//iterate through each row
for (int i = 0; i <rowCount ; i++) {
    //get the value of each cell in the row
    String cellValue2 =table.getValueAt(i, 1).toString();
    String cellValue3 = table.getValueAt(i, 2).toString();
    String cellValue4 = table.getValueAt(i, 3).toString();

    //add the values to the appropriate ArrayList
    column2.add(cellValue2);
    column3.add(cellValue3);
    column4.add(cellValue4);
}
        
    
    System.out.print(filename+"-writeFile");
     try (FileOutputStream fos = new FileOutputStream(filename+".data");
             DataOutputStream dos = new DataOutputStream(fos)) {
          for(int i=0;i<column2.size();i++){
            dos.writeUTF(column2.get(i));
            dos.writeUTF(column3.get(i));
            dos.writeUTF(column4.get(i));
           
    }
         JOptionPane.showMessageDialog(null, "Data saved successfully to 'NewRecord'");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error saving data to 'NewRecord': " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
   
   
 }
 
    public static void generateTotal(JTable tabel,JTextField tPrice){
         //Generate Total
       double totalPriceInCart=0.0;
       TableModel model_test = tabel.getModel();
       int rows = model_test.getRowCount();
       System.out.println(rows);
       for (int i = 0; i < rows; i++) {
                    
                double currPrice = (double) model_test.getValueAt(i, 1) ;
                totalPriceInCart=totalPriceInCart+currPrice;
                }
            tPrice.setText(Double.toString(totalPriceInCart));    
      
    }    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panelShoppingCart = new javax.swing.JPanel();
        panelThank = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        btnthank = new MyButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        btnClose = new MyButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemCart = new javax.swing.JTable();
        btnShop = new MyButton();
        btnDiscard = new MyButton();
        btndeleteAll = new MyButton();
        totalPrice = new javax.swing.JTextField();
        coverBlack = new javax.swing.JPanel();
        importPanel = new javax.swing.JPanel();
        txtFileName = new javax.swing.JTextField();
        btnimportfile = new MyButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        itemRecord = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        btnShowCart = new MyButton();
        btnAddToCart = new MyButton();
        jLabel5 = new javax.swing.JLabel();
        txtNameProd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtPriceProd = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        quantity = new javax.swing.JComboBox<>();
        btnAddToRecordTabel = new MyButton();
        btnDiscardRecordTabel = new MyButton();
        txtPID = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btnImport = new MyButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnLogout = new MyButton();
        btnAbout = new MyButton();
        userNameSet = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(500, 50, 852, 751));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(852, 751));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelShoppingCart.setBackground(new java.awt.Color(51, 51, 51));
        panelShoppingCart.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelThank.setBackground(new java.awt.Color(204, 204, 204));

        jLabel9.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/thank-you.png"))); // NOI18N
        jLabel9.setText("Than You! Come Again ....");
        jLabel9.setOpaque(true);

        btnthank.setBackground(new java.awt.Color(51, 51, 51));
        btnthank.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnthank.setForeground(new java.awt.Color(0, 204, 0));
        btnthank.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/buy.png"))); // NOI18N
        btnthank.setText("O K");
        btnthank.setToolTipText("Add items");
        btnthank.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnthank.setBorderPainted(false);
        btnthank.setFocusPainted(false);
        btnthank.setFocusable(false);
        btnthank.setIconTextGap(10);
        btnthank.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnthankMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnthankMouseExited(evt);
            }
        });
        btnthank.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnthankActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelThankLayout = new javax.swing.GroupLayout(panelThank);
        panelThank.setLayout(panelThankLayout);
        panelThankLayout.setHorizontalGroup(
            panelThankLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)
            .addComponent(btnthank, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelThankLayout.setVerticalGroup(
            panelThankLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelThankLayout.createSequentialGroup()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnthank, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelShoppingCart.add(panelThank, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 320, 130));

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));
        jPanel4.setForeground(new java.awt.Color(102, 102, 102));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI Historic", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/trolley.png"))); // NOI18N
        jLabel3.setText("SHOPPING CART");
        jLabel3.setIconTextGap(20);
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 65));

        btnClose.setBackground(new java.awt.Color(0, 0, 0));
        btnClose.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnClose.setForeground(new java.awt.Color(0, 204, 0));
        btnClose.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/remove (1).png"))); // NOI18N
        btnClose.setToolTipText("Add items");
        btnClose.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnClose.setBorderPainted(false);
        btnClose.setFocusPainted(false);
        btnClose.setFocusable(false);
        btnClose.setIconTextGap(10);
        btnClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCloseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCloseMouseExited(evt);
            }
        });
        btnClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseActionPerformed(evt);
            }
        });
        jPanel4.add(btnClose, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 0, 50, 40));

        panelShoppingCart.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 70));

        jScrollPane1.setBackground(new java.awt.Color(51, 51, 51));
        jScrollPane1.setBorder(null);
        jScrollPane1.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N

        itemCart.setAutoCreateRowSorter(true);
        itemCart.setBackground(new java.awt.Color(102, 102, 102));
        itemCart.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        itemCart.setForeground(new java.awt.Color(255, 255, 255));
        itemCart.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ITEM NAME", "PRICE", "AMOUNT"
            }
        ));
        itemCart.setGridColor(new java.awt.Color(0, 0, 0));
        itemCart.setRowHeight(30);
        itemCart.setSelectionBackground(new java.awt.Color(0, 0, 0));
        itemCart.setSelectionForeground(new java.awt.Color(204, 204, 204));
        jScrollPane1.setViewportView(itemCart);

        panelShoppingCart.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 820, 270));

        btnShop.setBackground(new java.awt.Color(51, 51, 51));
        btnShop.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnShop.setForeground(new java.awt.Color(0, 204, 0));
        btnShop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/buy.png"))); // NOI18N
        btnShop.setText("S H O P");
        btnShop.setToolTipText("Add items");
        btnShop.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnShop.setBorderPainted(false);
        btnShop.setFocusPainted(false);
        btnShop.setFocusable(false);
        btnShop.setIconTextGap(10);
        btnShop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnShopMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnShopMouseExited(evt);
            }
        });
        btnShop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShopActionPerformed(evt);
            }
        });
        panelShoppingCart.add(btnShop, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 180, 60));

        btnDiscard.setBackground(new java.awt.Color(51, 51, 51));
        btnDiscard.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnDiscard.setForeground(new java.awt.Color(0, 204, 0));
        btnDiscard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/remove.png"))); // NOI18N
        btnDiscard.setToolTipText("Delete Items");
        btnDiscard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnDiscard.setBorderPainted(false);
        btnDiscard.setFocusPainted(false);
        btnDiscard.setFocusable(false);
        btnDiscard.setIconTextGap(10);
        btnDiscard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnDiscardMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnDiscardMouseExited(evt);
            }
        });
        btnDiscard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDiscardActionPerformed(evt);
            }
        });
        panelShoppingCart.add(btnDiscard, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, 100, 80));

        btndeleteAll.setBackground(new java.awt.Color(51, 51, 51));
        btndeleteAll.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btndeleteAll.setForeground(new java.awt.Color(0, 204, 0));
        btndeleteAll.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/trash.png"))); // NOI18N
        btndeleteAll.setToolTipText("Add items");
        btndeleteAll.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btndeleteAll.setBorderPainted(false);
        btndeleteAll.setFocusPainted(false);
        btndeleteAll.setFocusable(false);
        btndeleteAll.setIconTextGap(10);
        btndeleteAll.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btndeleteAllMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btndeleteAllMouseExited(evt);
            }
        });
        btndeleteAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteAllActionPerformed(evt);
            }
        });
        panelShoppingCart.add(btndeleteAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 410, 80, 60));

        totalPrice.setBackground(new java.awt.Color(51, 51, 51));
        totalPrice.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        totalPrice.setForeground(new java.awt.Color(255, 255, 255));
        totalPrice.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        totalPrice.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 205, 0), 1, true), "TOTAL", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI Historic", 1, 14), new java.awt.Color(0, 204, 0))); // NOI18N
        panelShoppingCart.add(totalPrice, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 410, 170, 50));

        jPanel1.add(panelShoppingCart, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 510));

        coverBlack.setBackground(new java.awt.Color(0, 0, 0));
        coverBlack.setPreferredSize(new java.awt.Dimension(830, 470));
        coverBlack.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        importPanel.setBackground(new java.awt.Color(153, 153, 153));

        txtFileName.setBackground(new java.awt.Color(153, 153, 153));
        txtFileName.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        txtFileName.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtFileName.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true), "IMPORT USER NAME", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Historic", 0, 18))); // NOI18N
        txtFileName.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        btnimportfile.setBackground(new java.awt.Color(0, 0, 0));
        btnimportfile.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnimportfile.setForeground(new java.awt.Color(0, 204, 0));
        btnimportfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/import.png"))); // NOI18N
        btnimportfile.setText("I M P O R T");
        btnimportfile.setToolTipText("import from another user");
        btnimportfile.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnimportfile.setBorderPainted(false);
        btnimportfile.setFocusPainted(false);
        btnimportfile.setFocusable(false);
        btnimportfile.setIconTextGap(10);
        btnimportfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnimportfileMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnimportfileMouseExited(evt);
            }
        });
        btnimportfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnimportfileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout importPanelLayout = new javax.swing.GroupLayout(importPanel);
        importPanel.setLayout(importPanelLayout);
        importPanelLayout.setHorizontalGroup(
            importPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(importPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(importPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtFileName)
                    .addComponent(btnimportfile, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        importPanelLayout.setVerticalGroup(
            importPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(importPanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(txtFileName, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(btnimportfile, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        coverBlack.add(importPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 220, 390, 200));

        jScrollPane2.setBackground(new java.awt.Color(0, 0, 0));
        jScrollPane2.setBorder(null);

        itemRecord.setBackground(new java.awt.Color(0, 0, 0));
        itemRecord.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        itemRecord.setForeground(new java.awt.Color(255, 255, 255));
        itemRecord.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                { new Long(1), "Apples ", "1 kg",  new Double(2.99)},
                { new Long(2), "Bananas", "1 kg",  new Double(1.49)},
                { new Long(3), "Oranges", "1 kg ",  new Double(3.99)},
                { new Long(4), "Strawberries", " 0.5 kg ",  new Double(4.99)},
                { new Long(5), "Blueberries", "0.5 kg",  new Double(5.99)},
                { new Long(6), "Broccoli", "1 kg",  new Double(2.49)},
                { new Long(7), "Carrots", "1 kg",  new Double(1.99)},
                { new Long(8), "Onions  ", "1 kg",  new Double(1.79)},
                { new Long(9), "Potatoes", "1 kg",  new Double(2.29)},
                { new Long(10), "Tomatoes", "1 kg",  new Double(3.39)},
                { new Long(11), "Chicken Breast", "1 kg",  new Double(7.56)},
                { new Long(12), "Ground Beef", "1 kg",  new Double(8.99)},
                { new Long(13), "Pork Loin", "1 kg",  new Double(9.99)},
                { new Long(14), "Salmon", "1 kg",  new Double(14.99)},
                { new Long(15), "Tuna", "1 kg",  new Double(12.99)},
                { new Long(16), "Eggs", "1 dozen  ",  new Double(2.99)},
                { new Long(17), "Milk", "1 liter ",  new Double(1.99)},
                { new Long(18), "Bread", "1 loaf",  new Double(2.49)},
                { new Long(19), "Rice", "1 kg",  new Double(3.49)},
                { new Long(20), "Pasta", "1 kg",  new Double(2.99)}
            },
            new String [] {
                "P-ID", "Name", "Quantity", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Long.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        itemRecord.setRowSelectionAllowed(true);
        itemRecord.setColumnSelectionAllowed(false);
        itemRecord.setGridColor(new java.awt.Color(51, 51, 51));
        itemRecord.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        itemRecord.setGridColor(new java.awt.Color(51, 51, 51));
        itemRecord.setIntercellSpacing(new java.awt.Dimension(5, 5));
        itemRecord.setRowHeight(30);
        itemRecord.setSelectionBackground(new java.awt.Color(0, 153, 0));
        itemRecord.setSelectionForeground(new java.awt.Color(255, 255, 255));
        itemRecord.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        itemRecord.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        itemRecord.setShowGrid(false);
        itemRecord.setShowHorizontalLines(false);
        itemRecord.setShowVerticalLines(true);
        itemRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemRecordMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(itemRecord);
        itemRecord.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        coverBlack.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 730, 230));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("GROCERY ITEMS  ");
        jLabel2.setOpaque(true);
        coverBlack.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 330, -1));

        btnShowCart.setBackground(new java.awt.Color(0, 0, 0));
        btnShowCart.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnShowCart.setForeground(new java.awt.Color(0, 204, 0));
        btnShowCart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/trolley.png"))); // NOI18N
        btnShowCart.setText("C A R T ");
        btnShowCart.setToolTipText("Show cart");
        btnShowCart.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnShowCart.setBorderPainted(false);
        btnShowCart.setFocusPainted(false);
        btnShowCart.setFocusable(false);
        btnShowCart.setIconTextGap(10);
        btnShowCart.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnShowCartMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnShowCartMouseExited(evt);
            }
        });
        btnShowCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowCartActionPerformed(evt);
            }
        });
        coverBlack.add(btnShowCart, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 500, 140, 50));

        btnAddToCart.setBackground(new java.awt.Color(0, 0, 0));
        btnAddToCart.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnAddToCart.setForeground(new java.awt.Color(0, 204, 0));
        btnAddToCart.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/plus.png"))); // NOI18N
        btnAddToCart.setText("A D D  T O  C A R T ");
        btnAddToCart.setToolTipText("Add items");
        btnAddToCart.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnAddToCart.setBorderPainted(false);
        btnAddToCart.setFocusPainted(false);
        btnAddToCart.setFocusable(false);
        btnAddToCart.setIconTextGap(10);
        btnAddToCart.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddToCartMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddToCartMouseExited(evt);
            }
        });
        btnAddToCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddToCartActionPerformed(evt);
            }
        });
        coverBlack.add(btnAddToCart, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 500, 220, 50));

        jLabel5.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Name of Product");
        coverBlack.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 110, 40));

        txtNameProd.setBackground(new java.awt.Color(51, 51, 51));
        txtNameProd.setForeground(new java.awt.Color(204, 204, 204));
        txtNameProd.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNameProd.setBorder(null);
        txtNameProd.setCaretColor(new java.awt.Color(255, 255, 255));
        txtNameProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameProdActionPerformed(evt);
            }
        });
        coverBlack.add(txtNameProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 96, 230, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Quantity of Product");
        coverBlack.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 150, 40));

        txtPriceProd.setBackground(new java.awt.Color(51, 51, 51));
        txtPriceProd.setForeground(new java.awt.Color(204, 204, 204));
        txtPriceProd.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtPriceProd.setBorder(null);
        txtPriceProd.setCaretColor(new java.awt.Color(255, 255, 255));
        txtPriceProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPriceProdActionPerformed(evt);
            }
        });
        coverBlack.add(txtPriceProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, 80, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Price of Product");
        coverBlack.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 80, 130, 50));

        quantity.setBackground(new java.awt.Color(0, 0, 0));
        quantity.setEditable(true);
        quantity.setForeground(new java.awt.Color(204, 204, 204));
        quantity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 kg", "1 dozen", "0.5 kg", "2 dozen", "1 liter", "2 liter", "3 liter", "1 loaf", "2 loaf", "3 loaf" }));
        quantity.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51)));
        quantity.setFocusable(false);
        coverBlack.add(quantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, 170, -1));

        btnAddToRecordTabel.setBackground(new java.awt.Color(0, 0, 0));
        btnAddToRecordTabel.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnAddToRecordTabel.setForeground(new java.awt.Color(204, 204, 204));
        btnAddToRecordTabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/add.png"))); // NOI18N
        btnAddToRecordTabel.setToolTipText("Add items");
        btnAddToRecordTabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnAddToRecordTabel.setBorderPainted(false);
        btnAddToRecordTabel.setFocusPainted(false);
        btnAddToRecordTabel.setFocusable(false);
        btnAddToRecordTabel.setIconTextGap(30);
        btnAddToRecordTabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddToRecordTabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddToRecordTabelMouseExited(evt);
            }
        });
        btnAddToRecordTabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddToRecordTabelActionPerformed(evt);
            }
        });
        coverBlack.add(btnAddToRecordTabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, 70, 50));

        btnDiscardRecordTabel.setBackground(new java.awt.Color(0, 0, 0));
        btnDiscardRecordTabel.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnDiscardRecordTabel.setForeground(new java.awt.Color(0, 204, 0));
        btnDiscardRecordTabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/remove.png"))); // NOI18N
        btnDiscardRecordTabel.setText("D I S C A R D ");
        btnDiscardRecordTabel.setToolTipText("Add items");
        btnDiscardRecordTabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnDiscardRecordTabel.setBorderPainted(false);
        btnDiscardRecordTabel.setFocusPainted(false);
        btnDiscardRecordTabel.setFocusable(false);
        btnDiscardRecordTabel.setIconTextGap(10);
        btnDiscardRecordTabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnDiscardRecordTabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnDiscardRecordTabelMouseExited(evt);
            }
        });
        btnDiscardRecordTabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDiscardRecordTabelActionPerformed(evt);
            }
        });
        coverBlack.add(btnDiscardRecordTabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, 150, 50));

        txtPID.setBackground(new java.awt.Color(51, 51, 51));
        txtPID.setForeground(new java.awt.Color(204, 204, 204));
        txtPID.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtPID.setBorder(null);
        txtPID.setCaretColor(new java.awt.Color(255, 255, 255));
        txtPID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPIDActionPerformed(evt);
            }
        });
        coverBlack.add(txtPID, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 160, 80, 40));

        jLabel8.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("P-ID");
        coverBlack.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, 40, 40));

        btnImport.setBackground(new java.awt.Color(0, 0, 0));
        btnImport.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        btnImport.setForeground(new java.awt.Color(0, 204, 0));
        btnImport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/import.png"))); // NOI18N
        btnImport.setText("I M P O R T");
        btnImport.setToolTipText("import from another user");
        btnImport.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 0)));
        btnImport.setBorderPainted(false);
        btnImport.setFocusPainted(false);
        btnImport.setFocusable(false);
        btnImport.setIconTextGap(10);
        btnImport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnImportMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnImportMouseExited(evt);
            }
        });
        btnImport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportActionPerformed(evt);
            }
        });
        coverBlack.add(btnImport, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 500, 220, 50));

        jPanel1.add(coverBlack, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 850, 570));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/photo-1604719312566-8912e9227c6a.jpeg"))); // NOI18N
        jLabel4.setText("jLabel4");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-140, 0, 990, 660));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 91, 860, 660));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 0));
        jLabel1.setText("G - S T O R E");

        btnLogout.setBackground(new java.awt.Color(0, 0, 0));
        btnLogout.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/logout.png"))); // NOI18N
        btnLogout.setToolTipText("Log out");
        btnLogout.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 0), 1, true));
        btnLogout.setFocusable(false);
        btnLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnLogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnLogoutMouseExited(evt);
            }
        });
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnAbout.setBackground(new java.awt.Color(0, 0, 0));
        btnAbout.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        btnAbout.setForeground(new java.awt.Color(255, 255, 255));
        btnAbout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/customer-support.png"))); // NOI18N
        btnAbout.setToolTipText("Help/About");
        btnAbout.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 0), 1, true));
        btnAbout.setFocusable(false);
        btnAbout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAboutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAboutMouseExited(evt);
            }
        });
        btnAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAboutActionPerformed(evt);
            }
        });

        userNameSet.setBackground(new java.awt.Color(0, 0, 0));
        userNameSet.setFont(new java.awt.Font("Segoe UI Historic", 1, 24)); // NOI18N
        userNameSet.setForeground(new java.awt.Color(255, 255, 255));
        userNameSet.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        userNameSet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/EndUsers/user.png"))); // NOI18N
        userNameSet.setIconTextGap(20);
        userNameSet.setOpaque(true);
        userNameSet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                userNameSetMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                userNameSetMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addComponent(userNameSet, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btnAbout, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnAbout, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                    .addComponent(btnLogout, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(29, 29, 29))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(userNameSet, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 100));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void itemRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemRecordMouseClicked
           
    }//GEN-LAST:event_itemRecordMouseClicked

    private void btnShowCartMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnShowCartMouseEntered
        btnShowCart.setBackground(new Color(0,204,0));
        btnShowCart.setForeground(new Color(0,0,0));

    }//GEN-LAST:event_btnShowCartMouseEntered

    private void btnShowCartMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnShowCartMouseExited
        btnShowCart.setBackground(new Color(0,0,0));
        btnShowCart.setForeground(new Color(0,204,0));
    }//GEN-LAST:event_btnShowCartMouseExited

    private void btnShowCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowCartActionPerformed

        //total
        generateTotal(itemCart,totalPrice);
         

        itemRecord.setVisible(false);
        btnShowCart.setVisible(false);
        btnAddToCart.setVisible(false);      
        btnAddToRecordTabel.setVisible(false);
        btnDiscardRecordTabel.setVisible(false);
        panelShoppingCart.setVisible(true);
        
    }//GEN-LAST:event_btnShowCartActionPerformed

    private void btnAddToCartMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddToCartMouseEntered
       btnAddToCart.setBackground(new Color(0,204,0));
       btnAddToCart.setForeground(new Color(0,0,0));

    }//GEN-LAST:event_btnAddToCartMouseEntered

    private void btnAddToCartMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddToCartMouseExited
        btnAddToCart.setBackground(new Color(0,0,0));
        btnAddToCart.setForeground(new Color(0,204,0));
    }//GEN-LAST:event_btnAddToCartMouseExited

    private void btnAddToCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddToCartActionPerformed
       int selectedRow = itemRecord.getSelectedRow();
       int[] selectedRows = itemRecord.getSelectedRows();
        if (selectedRows.length > 0) {
            DefaultTableModel model = (DefaultTableModel) itemCart.getModel();
            for (int i = 0; i < selectedRows.length; i++) {
                Object itemName = itemRecord.getValueAt(selectedRows[i], 1);
                Object price = itemRecord.getValueAt(selectedRows[i], 3);
                Object amount = itemRecord.getValueAt(selectedRows[i], 2);
                model.addRow(new Object[] {itemName, price, amount});
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select row/rows from itemRecord table.");
        }

        
        //total
        generateTotal(itemCart,totalPrice);
        
        
     

    }//GEN-LAST:event_btnAddToCartActionPerformed

    private void btnShopMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnShopMouseEntered
        btnShop.setBackground(new Color(0,204,0));
         btnShop.setForeground(new Color(0,0,0));
    }//GEN-LAST:event_btnShopMouseEntered

    private void btnShopMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnShopMouseExited
     btnShop.setBackground(new Color(51,51,51));
     btnShop.setForeground(new Color(0,204,0));
    }//GEN-LAST:event_btnShopMouseExited

    private void btnShopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShopActionPerformed
        panelThank.setVisible(true);
        DefaultTableModel model = (DefaultTableModel) itemCart.getModel();
        model.setRowCount(0);

        //total
        generateTotal(itemCart,totalPrice);

    }//GEN-LAST:event_btnShopActionPerformed

    private void btnDiscardMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDiscardMouseEntered
         btnDiscard.setBackground(new Color(0,204,0));
         btnDiscard.setForeground(new Color(0,0,0));
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDiscardMouseEntered

    private void btnDiscardMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDiscardMouseExited
        btnDiscard.setBackground(new Color(51,51,51));
        btnDiscard.setForeground(new Color(0,204,0));
    }//GEN-LAST:event_btnDiscardMouseExited

    private void btnDiscardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDiscardActionPerformed
  int[] selectedRows = itemCart.getSelectedRows();
        if (selectedRows.length > 0) {
            DefaultTableModel model = (DefaultTableModel) itemCart.getModel();
            for (int i = selectedRows.length - 1; i >= 0; i--) {
                model.removeRow(selectedRows[i]);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select row/rows from itemCart table.");
        }
       
        //total
        generateTotal(itemCart,totalPrice);
         
    }//GEN-LAST:event_btnDiscardActionPerformed

    private void btnCloseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCloseMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCloseMouseEntered

    private void btnCloseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCloseMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCloseMouseExited

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        itemRecord.setVisible(true);
        btnShowCart.setVisible(true);
        btnAddToCart.setVisible(true);      
        btnAddToRecordTabel.setVisible(true);
        btnDiscardRecordTabel.setVisible(true);
        panelShoppingCart.setVisible(false);
                // TODO add your handling code here:
    }//GEN-LAST:event_btnCloseActionPerformed

    private void btnLogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLogoutMouseEntered
         btnLogout.setBackground(new Color(0,204,0));
         btnLogout.setForeground(new Color(0,0,0));

    }//GEN-LAST:event_btnLogoutMouseEntered

    private void btnLogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLogoutMouseExited
        btnLogout.setBackground(new Color(0,0,0));
        btnLogout.setForeground(new Color(255,255,255));

// TODO add your handling code here:
    }//GEN-LAST:event_btnLogoutMouseExited

    private void txtNameProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameProdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameProdActionPerformed

    private void txtPriceProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPriceProdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPriceProdActionPerformed

    private void btnAddToRecordTabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddToRecordTabelMouseEntered
             btnAddToRecordTabel.setBackground(new Color(0,204,0));
         btnAddToRecordTabel.setForeground(new Color(0,0,0));

        // TODO add your handling code here:
    }//GEN-LAST:event_btnAddToRecordTabelMouseEntered

    private void btnAddToRecordTabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddToRecordTabelMouseExited
            btnAddToRecordTabel.setBackground(new Color(0,0,0));
         btnAddToRecordTabel.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_btnAddToRecordTabelMouseExited

    private void btnAddToRecordTabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddToRecordTabelActionPerformed
                TableModel model_test = itemRecord.getModel();
                String productName = txtNameProd.getText();
                Double price=0.0;
                long id=0;
                if (!productName.matches("^[a-zA-Z][a-zA-Z0-9]*$")) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid name for product name.");
                    return;
                }
                try {
                     price = Double.parseDouble(txtPriceProd.getText());
                     id= Long.parseLong(txtPID.getText());
                
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid number for PID or Price.");
                    return;
                }
                
                int rows = model_test.getRowCount();
                System.out.println(rows);
                for (int i = 0; i < rows; i++) {
                    
                long recordId = (long) model_test.getValueAt(i, 0);
                String name = (String) model_test.getValueAt(i, 1);
                 if (txtNameProd.getText().equalsIgnoreCase(name) || Long.parseLong(txtPID.getText())==recordId ) {
                        JOptionPane.showMessageDialog(rootPane,"Data Already exsited!");
                        return;
                    }
                }
                
                String q =  (String) quantity.getSelectedItem();
                DefaultTableModel model = (DefaultTableModel) itemRecord.getModel();
                model.addRow(new Object[] {id,productName,q ,price });
                writeFile(itemRecord);
                
                txtNameProd.setText("");
                txtPriceProd.setText("");
                quantity.setSelectedIndex(0);
             
            

           
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAddToRecordTabelActionPerformed

    private void btndeleteAllMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndeleteAllMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btndeleteAllMouseEntered

    private void btndeleteAllMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndeleteAllMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btndeleteAllMouseExited

    private void btndeleteAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteAllActionPerformed
        DefaultTableModel model = (DefaultTableModel) itemCart.getModel();
        model.setRowCount(0);

        //total
        generateTotal(itemCart,totalPrice);
        // TODO add your handling code here:
    }//GEN-LAST:event_btndeleteAllActionPerformed

    private void btnDiscardRecordTabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDiscardRecordTabelMouseEntered
        btnDiscardRecordTabel.setBackground(new Color(0,204,0));
        btnDiscardRecordTabel.setForeground(new Color(0,0,0));
    }//GEN-LAST:event_btnDiscardRecordTabelMouseEntered

    private void btnDiscardRecordTabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDiscardRecordTabelMouseExited
        btnDiscardRecordTabel.setBackground(new Color(0,0,0));
        btnDiscardRecordTabel.setForeground(new Color(0,204,0));
    }//GEN-LAST:event_btnDiscardRecordTabelMouseExited

    private void btnDiscardRecordTabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDiscardRecordTabelActionPerformed
        int[] selectedRows = itemRecord.getSelectedRows();
        if (selectedRows.length > 0) {
            DefaultTableModel model = (DefaultTableModel) itemRecord.getModel();
            for (int i = selectedRows.length - 1; i >= 0; i--) {
                model.removeRow(selectedRows[i]);
                
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please select row/rows from itemCart table.");
        }
     writeFile(itemRecord);
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDiscardRecordTabelActionPerformed

    private void txtPIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPIDActionPerformed

    private void btnAboutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAboutMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAboutMouseEntered

    private void btnAboutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAboutMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAboutMouseExited

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
     super.dispose();
     DashBoard dash=new DashBoard(); 
     dash.setVisible(true);
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAboutActionPerformed
     String[] imageFiles = {"G1.jpg","G2.jpg", "G3.jpg", "G4.png","G5.jpg","G6.jpg"};
     super.dispose();
     About screen=new About(imageFiles,"customer",name); 
     screen.setVisible(true);
    }//GEN-LAST:event_btnAboutActionPerformed

    private void userNameSetMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userNameSetMouseEntered
      
        userNameSet.setBackground(new Color(0,204,0));
        userNameSet.setForeground(new Color(0,0,0));
// TODO add your handling code here:
    }//GEN-LAST:event_userNameSetMouseEntered

    private void userNameSetMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userNameSetMouseExited
        userNameSet.setBackground(new Color(0,0,0));
        
        userNameSet.setForeground(new Color(255,255,255));

        // TODO add your handling code here:
    }//GEN-LAST:event_userNameSetMouseExited

    private void btnthankMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnthankMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btnthankMouseEntered

    private void btnthankMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnthankMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btnthankMouseExited

    private void btnthankActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnthankActionPerformed
panelThank.setVisible(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_btnthankActionPerformed

    private void btnimportfileMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnimportfileMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btnimportfileMouseEntered

    private void btnimportfileMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnimportfileMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btnimportfileMouseExited

    private void btnimportfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnimportfileActionPerformed
        importPanel.setVisible(false);
        String newFileName=txtFileName.getText();
        if(newFileName.equals(name)||newFileName.equals("")){
            JOptionPane.showMessageDialog(rootPane, name+" can not Possible...");
            return;
        }
        newFileName=newFileName+"ItemRecord";
        readFile(itemRecord,newFileName);
        writeFile(itemRecord);
        // TODO add your handling code here:
    }//GEN-LAST:event_btnimportfileActionPerformed

    private void btnImportMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnImportMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btnImportMouseEntered

    private void btnImportMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnImportMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_btnImportMouseExited

    private void btnImportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportActionPerformed
        importPanel.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_btnImportActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customer(name).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbout;
    private javax.swing.JButton btnAddToCart;
    private javax.swing.JButton btnAddToRecordTabel;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnDiscard;
    private javax.swing.JButton btnDiscardRecordTabel;
    private javax.swing.JButton btnImport;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnShop;
    private javax.swing.JButton btnShowCart;
    private javax.swing.JButton btndeleteAll;
    private javax.swing.JButton btnimportfile;
    private javax.swing.JButton btnthank;
    private javax.swing.JPanel coverBlack;
    private javax.swing.JPanel importPanel;
    private javax.swing.JTable itemCart;
    private javax.swing.JTable itemRecord;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel panelShoppingCart;
    private javax.swing.JPanel panelThank;
    private javax.swing.JComboBox<String> quantity;
    private javax.swing.JTextField totalPrice;
    private javax.swing.JTextField txtFileName;
    private javax.swing.JTextField txtNameProd;
    private javax.swing.JTextField txtPID;
    private javax.swing.JTextField txtPriceProd;
    private javax.swing.JLabel userNameSet;
    // End of variables declaration//GEN-END:variables
}
